﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FessooFramework.BLL
{
    /// <summary>   A logger module.
    ///             Единый блок логирования</summary>
    ///
    /// <remarks>   AM Kozhevnikov, 22.01.2018. </remarks>

    class LoggerModule
    {
    }
}
