﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FessooFramework.BLL.Modules
{
    /// <summary>   A system state modules.
    ///             Модуль состояния системы </summary>
    ///
    /// <remarks>   AM Kozhevnikov, 22.01.2018. </remarks>

    public class SystemStateModules : Module
    {

    }
}
