﻿using FessooFramework.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FessooFramework.BLL
{
    /// <summary>   A module. 
    ///             Базовая повторно используемая оболочка модуля</summary>
    ///
    /// <remarks>   AM Kozhevnikov, 22.01.2018. </remarks>

    public class Module : SystemObject
    {
        #region Constructor
        public Module()
        {
            
        }

        public override void Default()
        {
        }
        #endregion
        #region Property

        #endregion
        #region Static methods
        // 1. Настройка по умолчанию
        // 2. Настройка по умолчанию Debug
        #endregion
    }
}
